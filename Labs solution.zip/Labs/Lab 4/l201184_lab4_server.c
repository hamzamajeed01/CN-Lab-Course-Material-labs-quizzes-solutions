/*
        UDP_Server. This Program will will create the Server side for UDP_Socket Programming.
        It will receive the data from the client and then send the same data back to client.
*/

#include <stdio.h> 
#include <string.h> 
#include <sys/socket.h> //// Needed for socket creating and binding
#include <arpa/inet.h> //inet_addr
#include <stdbool.h>

int find_student(char** roll_NOs, int n, char rollNo[8])  
{ 
	for (int j = 0; j < n; j++) 
	{ 
		 if(strcmp(roll_NOs[j], rollNo) == false) 
		 { 
		 	return j; 
		 } 
	} 
	return -1; 
} 
		 
int main(void)
{
        int socket_desc;
        struct sockaddr_in server_addr, client_addr;
        char server_message[2000], client_message[2000]; 
        int client_struct_length = sizeof(client_addr);
        
        //roll_Nos
        
        char** roll_Nos = calloc(100, sizeof(char*)); //roll_Nos containing roll numbers
        int counter = 0; 
        
        for(int i = 0; i < 100; i++)
        	roll_Nos[i] = calloc(8, sizeof(char));
        	
       
        	
        	bool check[10] = {false};
        
        //Cleaning the Buffers
        
        memset(server_message,'\0',sizeof(server_message));
        memset(client_message,'\0',sizeof(client_message));
        
        //Creating UDP Socket
        
        socket_desc = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        
        if(socket_desc < 0)
        {
                printf("Could Not Create Socket. Error!!!!!\n");
                return -1;
        }
        
        printf("Socket Created\n");
        
        //Binding IP and Port to socket
        
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(2000);
        server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");  // bind your socket to localhost only, if you want connect any particular ip you should mention it in INET_ADDR.
        
        if(bind(socket_desc, (struct sockaddr*)&server_addr, sizeof(server_addr))<0)
        {
                printf("Bind Failed. Error!!!!!\n");
                return -1;
        }        
        
        printf("Bind Done\n");
        
        printf("Listening for Messages...\n\n");
        
        //Receive the message from the client
        
        
        while (recvfrom(socket_desc, client_message, sizeof(client_message), 0, (struct sockaddr*)&client_addr,&client_struct_length))
        {
  
		printf("Received Message from IP: %s and Port No: %i\n",inet_ntoa(client_addr.sin_addr),ntohs(client_addr.sin_port));

		printf("Client Message: %s\n",client_message);
		
		char check_in_out[3]; //contains requested state 
		char temp_rollNo[8]; 
		
		for(int i = 0; i < 7; i++)
			temp_rollNo[i] = client_message[i]; 
		temp_rollNo[7] = '\0'; 
			
		check_in_out[0] = client_message[8];
		check_in_out[1] = client_message[9];
		check_in_out[2] = '\0';
		
		if(strcmp(check_in_out, "CI") == false) //student wants to check-in
		{
			if(find_student(roll_Nos, counter, temp_rollNo) == -1)
			{
				for(int i = 0; i < 7; i++)
					roll_Nos[counter][i] = temp_rollNo[i]; 
				roll_Nos[counter][7] = '\0'; 
				counter++; 
				char message[] = "Welcome Student ";
				strcat(message, temp_rollNo);
				strcpy(server_message, message);
			}
			
			else
			{
				strcpy(server_message, "You are already here.");
			}
		}
			
	       else if(strcmp(check_in_out, "CO") == false) //student wants to check-out 
	       { 
	       	int index_no = find_student(roll_Nos, counter, temp_rollNo); 
	       	if(index_no > -1)
	       	{ 
				char message[50] = "Good Bye Student ";
				strcat(message, temp_rollNo);
				strcat(message, " Have a nice day!");
				strcpy(server_message, message); 
				for (int x = 0; x < 7; x++) 
				{ 
					char t = roll_Nos[index_no][x]; 
					roll_Nos[index_no][x] = roll_Nos[counter-1][x]; 
					roll_Nos[counter-1][x] = t; 
				} 
				counter--; 
			}
			
			else
			{
				strcpy(server_message, "You didn’t check in today. Contact System Administrator.");
			}
		}
		
		else
		{
			strcpy(server_message, "Syntax error in requested state (CO/CI)");
		}
			
		//Send the message back to client
		
		if (sendto(socket_desc, server_message, strlen(server_message), 0, (struct sockaddr*)&client_addr,client_struct_length)<0)
		{
		        printf("Send Failed. Error!!!!!\n");
		        return -1;
		}
		
		printf("Displaying Roll Numbers in database: \n"); 
		for (int i = 0; i < counter; i++) 
		{ 
			printf("%s\n", roll_Nos[i]); 
		} 
		
		memset(server_message,'\0',sizeof(server_message));
		memset(client_message,'\0',sizeof(client_message));
	     
    }   
    
    //Closing the Socket 
    close(socket_desc);
    
    return 0;       
}
