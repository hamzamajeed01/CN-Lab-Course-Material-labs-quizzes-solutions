#include <stdio.h> 

int main() 
{ 
    short var = 5678; 
    char temp = var % 100; 
    if (temp==78) 
    { 
        printf("Big Endian"); 
    } 
    else 
    { 
        printf("Little Endian"); 
    } 
    
    getchar(); 
    return 0; 
} 
