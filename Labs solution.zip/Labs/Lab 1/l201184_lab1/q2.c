#include <stdio.h>
#include <stdlib.h>

int main()
{ 
   FILE *fptr;
   char string[2][255]; 

   if ((fptr = fopen("input.txt","r+")) == NULL){
       printf("Error! opening file"); 

       // Program exits if the file pointer returns NULL.
       exit(1);
   } 
   
   int i, j, k; 

   fgets(string[0], 255, (FILE*)fptr); 
   fgets(string[1], 255, (FILE*)fptr); 
   
   
   char nums[10][5]; 
   int count = 0; 
   char temp[5]; 
   int tc = 0; 
   int flag = 0; 
   
   for (i = 0; i < 2; i++) 
   { 
   	for (j = 0; string[i][j] != '\n'; j++) 
   	{ 
   		if (string[i][j] == ' ') 
   		{ 
   			do 
   			{ 
   				j++; 
   				if (string[i][j] > 47 && string[i][j] < 58) 
   				{ 
   					temp[tc++] = string[i][j]; 
   				} 
   				else if (string[i][j] == ' ') 
   				{ 
   					flag = 1; 
   				} 
   				else 
   				{ 
   					break; 
   				} 
   			} while (string[i][j] != ' '); 
   		} 
   		if (flag == 1) 
   		{ 
   			for (k = 0; k < tc; k++) 
   			{ 
   				nums[count][k] = temp[k]; 
   			} 
   			nums[count][k] = '\0'; 
   			count++; 
   		} 
   		tc = 0; 
   		flag = 0; 
   	} 
   } 
   
   for (i = 0; i < count; i++) 
   { 
   	printf("%s\n", nums[i]); 
   } 
   
   fclose(fptr); 
  
   return 0;
}
