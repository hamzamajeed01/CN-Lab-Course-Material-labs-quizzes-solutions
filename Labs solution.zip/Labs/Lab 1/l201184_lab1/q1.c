#include <stdio.h>
#include <stdlib.h>

int main()
{ 
   FILE *fptr;
   char string[2][255]; 

   if ((fptr = fopen("input.txt","r+")) == NULL){
       printf("Error! opening file");

       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   
   
   fgets(string[0], 255, (FILE*)fptr); 
   fgets(string[1], 255, (FILE*)fptr); 
   
   printf("%s", string[0]); 
   printf("%s", string[1]); 
   
   fclose(fptr); 
  
   return 0;
}
