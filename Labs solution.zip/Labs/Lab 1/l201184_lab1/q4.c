#include <stdio.h>
#include <stdlib.h>

int main()
{ 
   FILE *fptr;
   FILE *fptr2; 
   fptr2 = fopen("newFile.txt","w+"); 
   char string[2][255]; 

   if ((fptr = fopen("input.txt","r+")) == NULL){
       printf("Error! opening file"); 

       // Program exits if the file pointer returns NULL.
       exit(1);
   } 
   
   int i, j, k; 

   fgets(string[0], 255, (FILE*)fptr); 
   fgets(string[1], 255, (FILE*)fptr); 

   int tc = 0; 
   int flag = 0; 
   char x; 
   
   for (i = 0; i < 2; i++) 
   { 
   	for (j = 0; string[i][j] != '\n'; j++) 
   	{ 
   		if (string[i][j] == ' ' || j == 0) 
   		{ 
   			do 
   			{ 
   				j++; 
   				tc++; 
   				if (string[i][j] == 'a' || string[i][j] == 'e' || string[i][j] == 'i' || string[i][j] == 'o' || string[i][j] == 'u' || string[i][j] == 'A' || string[i][j] == 'E'|| string[i][j] == 'I' || string[i][j] == 'O' || string[i][j] == 'U')
   				{ 
   					flag = 1; 
   				} 
   				else if (string[i][j] == ' ') 
   				{ 
   					break; 
   				} 
   			} while (string[i][j] != ' '); 
   		} 
   		if (flag == 1) 
   		{ 
   			for (k = 0; k < (tc/2); k++) 
   			{ 
   				x = string[i][j+k]; 
   				string[i][j+k] = string[i][j+tc-k-1]; 
   				string[i][j+tc-k-1] = x; 
   			} 
   		} 
   		tc = 0; 
   		flag = 0; 
   	} 
   } 
   
   //output in file  
   printf("%s", string[0]);
   fputs(string[0], fptr2);
   fputc(' ', fptr2);
   printf("%s", string[1]);
   fputs(string[1], fptr2);
   fputc(' ', fptr2);

   fclose(fptr); 
   fclose(fptr2); 
  
   return 0; 
}
