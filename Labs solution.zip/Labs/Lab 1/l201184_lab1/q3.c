#include <stdio.h>
#include <stdlib.h>

int main()
{ 
   FILE *fptr;
   FILE *fptr2; 
   fptr2 = fopen("newFile.txt","w+"); 
   char string[2][255]; 

   if ((fptr = fopen("input.txt","r+")) == NULL){
       printf("Error! opening file"); 

       // Program exits if the file pointer returns NULL.
       exit(1);
   } 
   
   int i, j, k; 

   fgets(string[0], 255, (FILE*)fptr); 
   fgets(string[1], 255, (FILE*)fptr); 
   
   
   char nonchars[10][15]; 
   int count = 0; 
   char temp[15]; 
   int tc = 0; 
   int flag = 0; 
   
   for (i = 0; i < 2; i++) 
   { 
   	for (j = 0; string[i][j] != '\n'; j++) 
   	{ 
   		if (string[i][j] == ' ') 
   		{ 
   			do 
   			{ 
   				j++; 
   				if ((string[i][j] >= 'a' && string[i][j] <= 'z') || (string[i][j] >= 'A' && string[i][j] <= 'Z'))
   				{ 
   					break; 
   				} 
   				else if (string[i][j] == ' ') 
   				{ 
   					flag = 1; 
   				} 
   				else 
   				{ 
   					temp[tc++] = string[i][j]; 
   				} 
   			} while (string[i][j] != ' '); 
   		} 
   		if (flag == 1) 
   		{ 
   			for (k = 0; k < tc; k++) 
   			{ 
   				nonchars[count][k] = temp[k]; 
   			} 
   			nonchars[count][k] = '\0'; 
   			count++; 
   		} 
   		tc = 0; 
   		flag = 0; 
   	} 
   } 
   
   //output in file 
   for (i = 0; i < count; i++) 
   { 
       printf("%s", nonchars[i]);
       fputs(nonchars[i], fptr2);
       fputc(' ', fptr2);
   } 
   
   fclose(fptr); 
   fclose(fptr2); 
  
   return 0;
}
