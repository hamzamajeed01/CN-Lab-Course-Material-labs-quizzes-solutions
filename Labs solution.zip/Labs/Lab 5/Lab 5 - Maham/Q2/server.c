/*
        TCP_Server. This Program will will create the Server side for TCP_Socket Programming.
        It will receive the data from the client and then send the same data back to client.
*/

#include <stdio.h> 
#include <string.h> 
#include <sys/socket.h> //socket
#include <arpa/inet.h> //inet_addr
#include <stdbool.h>
#include <pthread.h>
#include<fcntl.h>
#include <unistd.h>

struct voter
{
	char name[50];
	char cnic[16];
	bool voted;
};

struct candidate
{
	char name[50];
	char symbol[10];
};

//Global variable accessible to all threads
int connections = 0;
struct voter voters[10];
struct candidate candidates[3];

void *deal_client (void *arg)
{
				connections++;
        int* c_sock = (int*)arg;   
        		
        char client_message[100];
        char server_message[1000];
        
        //memset(server_message,'\0',sizeof(server_message));
        //memset(client_message,'\0',sizeof(client_message));
        
        if (recv(c_sock, client_message, sizeof(client_message),0) < 0)
        {
                printf("Receive Failed. Error!!!!!\n");
                pthread_exit(NULL);
        }   
        
        //client_message[(strlen(client_message) - 2)] = '\0';
        printf("%s\n", client_message);
        
        char name[50];
        char cnic[16];
        bool turn = false;
        int k = 0;
        int l = 0;
        
        for(int j = 0; j < strlen(client_message); j++)
						{
								if(client_message[j] == '/'){
										turn = true;
										name[l] = '\0';
								}
										
								else if(turn == true)
										cnic[k++] = client_message[j];
										
								else
										name[l++] = client_message[j];
						}
						
				cnic[15] = '\0';
        
        bool found = false;
        
        
        for(int i = 0; i < 10 && found == false; i++)
        {
        		if(strcmp(name, voters[i].name) == false){
        				found = true;
        				printf("Found Name\n");
        		}
        }
        
        int index = 0;
        
        if(found)
        {
        		found = false;
        		for(; index < 10 && !found; index++)
        		{
        				if(strcmp(cnic, voters[index].cnic) == false){
        						found = true;
        						printf("Found CNIC\n");
        				}
        		}
        }
        
        if(found)
        {//welcome and vote and out file vote
        
        		if(voters[index - 1].voted == true)
        		{
        				strcpy(server_message, "Error. You have already voted.");
        				if (send(c_sock, server_message, strlen(server_message),0)<0)
        				{
                		printf("Send Failed. Error!!!!!\n");
                		pthread_exit(NULL);
        				}
        				
        				close(c_sock);
        				pthread_exit(NULL);
        		}
        
        		strcpy(server_message, "Welcome ");
        		strcat(server_message, voters[index - 1].name);
        		strcat(server_message, "\n");
        		strcat(server_message, "\nPlease cast your vote.\n\n");
        		
        		printf("Idher dekho theek hai :)\n");
        		for(int i = 0; i < 3; i++)
   		 			{
   		 					printf("Name: %s\n", candidates[i].name);
   		 					printf("Symbol: %s\n", candidates[i].symbol);
   		 			}
   		 			        		
        		for(int i = 0; i < 3; i++)
   		 			{
   		 					strcat(server_message,"Name: "); 
   		 					strcat(server_message, candidates[i].name);
   		 					strcat(server_message,"\n");
   		 					strcat(server_message,"Symbol: ");
   		 					strcat(server_message, candidates[i].symbol);
   		 					strcat(server_message,"\n");
   		 			}
   		 			
        		
        		if (send(c_sock, server_message, strlen(server_message),0)<0)
        		{
                printf("Send Failed. Error!!!!!\n");
                pthread_exit(NULL);
        		}
        		
        		memset(server_message,'\0',sizeof(server_message));
       			memset(client_message,'\0',sizeof(client_message));
        		
        		if (recv(c_sock, client_message, 100,0) < 0)
        		{
                printf("Receive Failed. Error!!!!!\n");
                pthread_exit(NULL);
        		}
        		
        		char temp[100];
        		strcpy(temp, client_message);
        		strtok(temp, "\n");
        		printf("%s", temp);
        		
        		memset(server_message,'\0',sizeof(server_message));
        		
        		FILE* fp;
        		fp = fopen("election_results.txt", "a");
        		fprintf(fp, "Name: %s CNIC: %s Voted: %s", voters[index - 1].name, voters[index - 1].cnic, temp);
        		fclose(fp);
        		voters[index - 1].voted = true;
        		strcpy(server_message, "Your vote has been recorded");
        				
        		if (send(c_sock, server_message, strlen(server_message),0)<0)
        		{
              		printf("Send Failed. Error!!!!!\n");
                	pthread_exit(NULL);
        		}	
        				
        		close(c_sock);
        		pthread_exit(NULL);
        		
        		  	
        }
        
        else
        {//send error
        
        		strcpy(server_message, "Unregistered Voter.\n");
        		if (send(c_sock, server_message, strlen(server_message),0)<0)
        		{
                printf("Send Failed. Error!!!!!\n");
                pthread_exit(NULL);
        		}	
        		close(c_sock);
        		pthread_exit(NULL);
        }   
}

int main(void)
{

        int socket_desc, client_sock, client_size; 
        struct sockaddr_in server_addr, client_addr;         //SERVER ADDR will have all the server address
        char server_message[2000], client_message[2000];
        
        pthread_t threads[5];                // Sending values from the server and receive from the server we need this

        //Cleaning the Buffers
        
        memset(server_message,'\0',sizeof(server_message));
        memset(client_message, '\0',sizeof(client_message));     // Set all bits of the padding field//
        
        //Creating database
        
        FILE* demo; 
  
    		// Creates a file "demo_file" 
    		// with file acccess as write-plus mode 
    		int i = 0;
   		  demo = fopen("Voters_List.txt", "r+"); 
    		char c[100]; 
    		
    		for(int r = 0; r < 100; r++)
    				c[r] = '\0';
    				
  			while (fgets(c, 100, demo) != NULL)
				{
						//printf("String: %s", c);
						bool id = false;
						int k = 0;
						int l = 0;

						for(int j = 0; j < strlen(c) + 1; j++)
						{
								if(c[j] == '/'){
										id = true;
										voters[i].name[l] = '\0';
								}
										
								else if(id == true)
										voters[i].cnic[k++] = c[j];
										
								else
										voters[i].name[l++] = c[j];
								
						}
						
						voters[i].cnic[15] = '\0';
						voters[i].voted = false;
						i++;
				}
    		// closes the file pointed by demo 
   		 	fclose(demo); 
  
        FILE* cands;
        
        cands = fopen("Candidates_List.txt", "r+");
        //Creating Socket
        
        char buff[25];
        for(int i = 0; i < 25; i++)
        		buff[i] = '\0';
        		
        int itr = 0;		
        while(fgets(buff, 25, cands) != NULL)
        {
        		bool turn = false;
						int k = 0;
						int l = 0;
						
						for(int j = 0; j < strlen(buff) + 1; j++)
						{
								if(buff[j] == '	')
								{
									turn = true;
									candidates[itr].name[l] = '\0';
								}
								
								else if(turn == true)
									candidates[itr].symbol[k++] = buff[j];
								
								else
									candidates[itr].name[l++] = buff[j];
						}
						
						candidates[itr].symbol[k - 2] = '\0';
						itr++;
        }
        
        fclose(cands); 
       
       
       	//for(int i = 0; i < 3; i++)
   		 	//{
   		 		//printf("Name: %s\n", candidates[i].name);
   		 		//printf("Symbol: %s\n", candidates[i].symbol);
   		 	//}
   		 	
   		 	//for(int i = 0; i < 10; i++)
   		 	//{
   		 		//printf("Name: %s\n", voters[i].name);
   		 		//printf("CNIC: %s\n", voters[i].cnic);
   		 	//}
        
        socket_desc = socket(AF_INET, SOCK_STREAM, 0);
        
        if(socket_desc < 0)
        {
                printf("Could Not Create Socket. Error!!!!!\n");
                return -1;
        }
        
        printf("Socket Created\n");
        
        //Binding IP and Port to socket
        
        server_addr.sin_family = AF_INET;               /* Address family = Internet */
        server_addr.sin_port = htons(2000);               // Set port number, using htons function to use proper byte order */
        server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");    /* Set IP address to localhost */
		
		
		
		// BINDING FUNCTION
        
        if(bind(socket_desc, (struct sockaddr*)&server_addr, sizeof(server_addr))<0)    // Bind the address struct to the socket.  /
	                            	//bind() passes file descriptor, the address structure,and the length of the address structure
        {
                printf("Bind Failed. Error!!!!!\n");
                return -1;
        }        
        
        printf("Bind Done\n");
        
        //Put the socket into Listening State
        
        if(listen(socket_desc, 1) < 0)                               //This listen() call tells the socket to listen to the incoming connections.
     		// The listen() function places all incoming connection into a "backlog queue" until accept() call accepts the connection.
        {
                printf("Listening Failed. Error!!!!!\n");
                return -1;
        }
        
        printf("Listening for Incoming Connections.....\n");
        
        //Accept the incoming Connections
        
        client_size = sizeof(client_addr);
		
        while(client_sock = accept(socket_desc, (struct sockaddr*)&client_addr, &client_size)){;          // heree particular client k liye new socket create kr rhaa ha
        
        if (client_sock < 0)
        {
                printf("Accept Failed. Error!!!!!!\n");
                return -1;
        }
        
        if (connections >= 5){
        		strcpy(server_message, "Server Full");
        				
        		if (send(client_sock, server_message, strlen(server_message),0)<0)
        		{
               			printf("Send Failed. Error!!!!!\n");
                		return -1;
        		}
        		
        		close(client_sock);
        }
        
        else{
        
        	int ret1 = pthread_create(&threads[connections],NULL,deal_client,(void*)client_sock);
        	if(ret1!=0)
        	{
         	       printf("Thread Creation Failed\n");
        	}
        	
        	pthread_join(threads[connections],NULL);
        	
        }
              
      }
    
        close(socket_desc);
        return 0;       
}
